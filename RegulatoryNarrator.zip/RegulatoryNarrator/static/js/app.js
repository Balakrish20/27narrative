$(document).ready(function() {
    // Define column mapping
    const columns = [
        "regulatory_ID", "case_justification", "case_type", "reporter_type", "publication_title", "country", "IRD",
        "age", "gender", "suspect_drug", "co_suspect_drug", "event", "medical_history", "past_drug_therapy",
        "concurrent_condition", "concomitant_medication", "dose", "frequency", "route", "indication",
        "suspect_drug_start_date"
    ];

    let dataTable = null;

    // Initialize DataTable
    function initializeDataTable() {
        if (dataTable) {
            dataTable.destroy();
        }
        
        dataTable = $('#dataTable').DataTable({
            scrollX: true,
            scrollY: '400px',
            pageLength: 25,
            lengthMenu: [[10, 25, 50, 100, -1], [10, 25, 50, 100, "All"]],
            columnDefs: [
                { width: "120px", targets: "_all" }
            ],
            language: {
                emptyTable: "No regulatory data available. Use 'Paste from Clipboard' to add data."
            }
        });
    }

    // Initialize DataTable on page load
    initializeDataTable();

    // Show status message
    function showStatus(message, type = 'info') {
        const alertClass = type === 'error' ? 'alert-danger' : 
                          type === 'success' ? 'alert-success' : 
                          type === 'warning' ? 'alert-warning' : 'alert-info';
        
        const statusHtml = `
            <div class="alert ${alertClass} alert-dismissible fade show" role="alert">
                <i class="bi bi-${type === 'error' ? 'exclamation-triangle' : 
                                   type === 'success' ? 'check-circle' : 
                                   type === 'warning' ? 'exclamation-triangle' : 'info-circle'} me-2"></i>
                ${message}
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>
        `;
        $('#statusMessages').html(statusHtml);
    }

    // Paste from clipboard
    $('#pasteBtn').click(async function() {
        try {
            const text = await navigator.clipboard.readText();
            const rows = text.trim().split('\n').map(row => row.split('\t'));
            
            if (rows.length === 0) {
                showStatus('No data found in clipboard', 'warning');
                return;
            }

            // Clear existing data
            dataTable.clear();

            // Add rows to table
            rows.forEach(row => {
                // Pad row with empty strings if needed
                while (row.length < columns.length) {
                    row.push('');
                }
                // Trim to exact column count
                row = row.slice(0, columns.length);
                dataTable.row.add(row);
            });

            dataTable.draw();
            showStatus(`Successfully pasted ${rows.length} rows of data`, 'success');
            
        } catch (error) {
            console.error('Paste error:', error);
            showStatus('Unable to paste from clipboard. Please ensure you have copied tabulated data.', 'error');
        }
    });

    // Clear table
    $('#clearBtn').click(function() {
        dataTable.clear().draw();
        showStatus('Table cleared', 'info');
    });

    // Generate narratives
    $('#generateBtn').click(function() {
        const data = dataTable.data().toArray();
        
        if (data.length === 0) {
            showStatus('No data available to generate narratives', 'warning');
            return;
        }

        // Convert array data to objects
        const formattedData = data.map(row => {
            const obj = {};
            columns.forEach((col, index) => {
                obj[col] = row[index] || '';
            });
            return obj;
        });

        // Show loading modal
        const loadingModal = new bootstrap.Modal(document.getElementById('loadingModal'));
        loadingModal.show();

        // Send data to server
        fetch('/generate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ data: formattedData })
        })
        .then(response => response.json())
        .then(result => {
            loadingModal.hide();
            
            if (result.error) {
                showStatus(`Generation failed: ${result.error}`, 'error');
                return;
            }

            displayNarratives(result.results);
            
            // Switch to output tab
            const outputTab = new bootstrap.Tab(document.getElementById('output-tab'));
            outputTab.show();
            
            showStatus(`Successfully generated ${result.results.length} narratives`, 'success');
        })
        .catch(error => {
            loadingModal.hide();
            console.error('Generation error:', error);
            showStatus('Failed to generate narratives. Please check your data and try again.', 'error');
        });
    });

    // Display narratives in output tab
    function displayNarratives(results) {
        let outputHtml = '';
        
        results.forEach((result, index) => {
            const narrativeFormatted = result.narrative.replace(/\n\n/g, '</p><p>').replace(/\n/g, '<br>');
            
            outputHtml += `
                <div class="card mb-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h6 class="mb-0">
                            <i class="bi bi-file-earmark-text me-2"></i>
                            Regulatory ID: <span class="badge bg-primary">${result.regulatory_ID}</span>
                        </h6>
                        <button type="button" class="btn btn-sm btn-outline-secondary copy-narrative-btn" 
                                data-narrative="${escapeHtml(result.narrative)}">
                            <i class="bi bi-clipboard me-1"></i>Copy
                        </button>
                    </div>
                    <div class="card-body">
                        <div class="narrative-text">
                            <p>${narrativeFormatted}</p>
                        </div>
                    </div>
                </div>
            `;
        });

        $('#narrativeOutput').html(outputHtml);

        // Add copy functionality to individual narrative buttons
        $('.copy-narrative-btn').click(function() {
            const narrative = $(this).data('narrative');
            navigator.clipboard.writeText(narrative).then(() => {
                const originalText = $(this).html();
                $(this).html('<i class="bi bi-check me-1"></i>Copied!');
                setTimeout(() => {
                    $(this).html(originalText);
                }, 2000);
            });
        });
    }

    // Copy all narratives
    $('#copyAllBtn').click(function() {
        const narratives = [];
        $('.copy-narrative-btn').each(function() {
            const narrative = $(this).data('narrative');
            if (narrative) {
                const regId = $(this).closest('.card').find('.badge').text();
                narratives.push(`Regulatory ID: ${regId}\n${narrative}\n\n${'='.repeat(60)}\n`);
            }
        });

        if (narratives.length === 0) {
            showStatus('No narratives to copy', 'warning');
            return;
        }

        const allText = narratives.join('\n');
        navigator.clipboard.writeText(allText).then(() => {
            const originalText = $(this).html();
            $(this).html('<i class="bi bi-check me-1"></i>Copied All!');
            setTimeout(() => {
                $(this).html(originalText);
            }, 2000);
        });
    });

    // Clear output
    $('#clearOutputBtn').click(function() {
        $('#narrativeOutput').html(`
            <div class="text-center text-muted py-5">
                <i class="bi bi-file-text display-1 opacity-25"></i>
                <p class="mt-3">No narratives generated yet. Please input data and generate narratives from the Data Input tab.</p>
            </div>
        `);
        showStatus('Output cleared', 'info');
    });

    // Utility function to escape HTML
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Add sample data for testing (optional)
    $('#addSampleBtn').click(function() {
        const sampleData = [
            ["REG001", "serious", "spontaneous", "healthcare professional", "Case Study of Adverse Drug Reaction", "USA", "2024-01-15", "45", "male", "Drug A", "Drug B", "rash", "hypertension", "none", "diabetes", "insulin", "10mg", "twice daily", "oral", "pain relief", "2024-01-10"]
        ];
        
        dataTable.clear();
        sampleData.forEach(row => {
            dataTable.row.add(row);
        });
        dataTable.draw();
        showStatus('Sample data added', 'success');
    });
});
